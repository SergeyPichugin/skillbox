"use strict"

import { User, UserList } from "./lib.js"
// new User("Sergey", "Pichguin")
window.UserList = UserList
window.User = User
UserList.add();