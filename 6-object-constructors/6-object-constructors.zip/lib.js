"use strict"

let UserList = {
    users: [],
    add: function(user) {
        let question = prompt("Введите имя и фамилию через пробел:")
        
        if (question === null) { this.getAllUsers() } else if (question == "" || question === undefined) {
            alert('Вы не ввели ничего!')
            this.add()
        } else if (!isNaN(parseFloat(question)) && isFinite(question)) { 
            alert('Вы ввели число')
            this.add()
        } else {
            question = question.split(" ")            
            if( !isNaN(parseFloat(question[0])) || isFinite(question[1]) ){
                alert('Вы ввели число 2')
                this.add()
            }
            else if(question.length >= 3) {
                alert('Вы ввели больше 2 слов')
                this.add()
            } else {
                user = question
                    this.users.forEach(function(el) {
                        if(el[0] == user[0] && el[1] == user[1]){
                            alert('Такой пользователь уже суще') 
                            UserList.users.pop()                                                     
                        }                        
                    })
                console.log(user)
                this.users.push(user)
                this.add()
            }
            
        }
    },
    getAllUsers: function() {
        this.users.forEach(function(el) {
            new User(el[0], el[1])
        })
    }
}

function User(firstName, lastName) {    
    let output = document.getElementById('listUsers')
    this.firstName = firstName
    this.lastName = lastName
    this.regDate = Date()    
    if (this.lastName === undefined) {
        output.innerHTML += '<li> ( ° ͟ʖ °) ' + 'Имя: ' + this.firstName + ', Дата регистрации: ' + this.regDate + '</li>'
    } else {
        output.innerHTML += '<li> ( ° ͟ʖ °) ' + 'Имя: ' + this.firstName + ', Фамилия: ' + this.lastName + ', Дата регистрации: ' + this.regDate + '</li>'
    }
}

export { User, UserList }